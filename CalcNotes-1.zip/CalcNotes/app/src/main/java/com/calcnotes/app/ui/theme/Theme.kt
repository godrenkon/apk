package com.calcnotes.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// 電卓の「紙テープ」を思わせる、インクと紙質感の落ち着いた配色。
// 式(入力)は控えめなグレー、答えは強調するインク色というコントラストで
// チャット吹き出しの「問い→答え」の関係を視覚化する。
val PaperCream = Color(0xFFFBF9F4)
val PaperCreamDim = Color(0xFFF1EEE5)
val InkNavy = Color(0xFF1F2A44)
val InkSlate = Color(0xFF5B6478)
val AccentAmber = Color(0xFFC97A2B)
val ErrorRust = Color(0xFFB3441E)

val DarkGraphite = Color(0xFF15171C)
val DarkGraphiteDim = Color(0xFF1E212A)
val DarkPaper = Color(0xFFE9E6DD)
val DarkSlate = Color(0xFF9AA3B5)

private val LightColors = lightColorScheme(
    background = PaperCream,
    surface = PaperCreamDim,
    primary = InkNavy,
    onPrimary = PaperCream,
    secondary = AccentAmber,
    onBackground = InkNavy,
    onSurface = InkNavy,
    error = ErrorRust
)

private val DarkColors = darkColorScheme(
    background = DarkGraphite,
    surface = DarkGraphiteDim,
    primary = DarkPaper,
    onPrimary = DarkGraphite,
    secondary = AccentAmber,
    onBackground = DarkPaper,
    onSurface = DarkPaper,
    error = Color(0xFFE0846A)
)

@Composable
fun CalcNotesTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = CalcNotesTypography,
        content = content
    )
}
