package com.calcnotes.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.calcnotes.app.data.Session

/**
 * 左側に表示するセッション(電卓ページ)一覧。
 * タップで切り替え、長押しや専用ボタンで名前変更・削除ができる。
 */
@Composable
fun SessionSidebar(
    sessions: List<Session>,
    currentSessionId: Long?,
    onSelect: (Session) -> Unit,
    onCreate: () -> Unit,
    onRename: (Session, String) -> Unit,
    onDelete: (Session) -> Unit,
    modifier: Modifier = Modifier
) {
    var sessionPendingRename by remember { mutableStateOf<Session?>(null) }
    var sessionPendingDelete by remember { mutableStateOf<Session?>(null) }

    Column(
        modifier = modifier
            .background(MaterialTheme.colorScheme.surface)
            .padding(vertical = 12.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "電卓ページ",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            IconButton(onClick = onCreate) {
                Icon(Icons.Filled.Add, contentDescription = "新しい電卓ページを作る")
            }
        }

        LazyColumn(
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(horizontal = 8.dp)
        ) {
            items(sessions, key = { it.id }) { session ->
                SessionRow(
                    session = session,
                    isSelected = session.id == currentSessionId,
                    onSelect = { onSelect(session) },
                    onRenameClick = { sessionPendingRename = session },
                    onDeleteClick = { sessionPendingDelete = session }
                )
            }
        }
    }

    // 名前変更ダイアログ
    sessionPendingRename?.let { session ->
        RenameDialog(
            initialName = session.name,
            onConfirm = { newName ->
                onRename(session, newName)
                sessionPendingRename = null
            },
            onDismiss = { sessionPendingRename = null }
        )
    }

    // 削除確認ダイアログ
    sessionPendingDelete?.let { session ->
        AlertDialog(
            onDismissRequest = { sessionPendingDelete = null },
            title = { Text("「${session.name}」を削除しますか?") },
            text = { Text("この電卓ページの計算履歴もすべて削除されます。この操作は取り消せません。") },
            confirmButton = {
                TextButton(onClick = {
                    onDelete(session)
                    sessionPendingDelete = null
                }) {
                    Text("削除する", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { sessionPendingDelete = null }) {
                    Text("キャンセル")
                }
            }
        )
    }
}

@Composable
private fun SessionRow(
    session: Session,
    isSelected: Boolean,
    onSelect: () -> Unit,
    onRenameClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val background = if (isSelected) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)
    else MaterialTheme.colorScheme.surface

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(background)
            .clickable { onSelect() }
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = session.name,
            style = MaterialTheme.typography.bodyMedium,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.weight(1f)
        )
        Row {
            IconButton(onClick = onRenameClick, modifier = Modifier.size(32.dp)) {
                Icon(
                    Icons.Filled.Edit,
                    contentDescription = "名前を変更",
                    modifier = Modifier.size(16.dp)
                )
            }
            IconButton(onClick = onDeleteClick, modifier = Modifier.size(32.dp)) {
                Icon(
                    Icons.Filled.Delete,
                    contentDescription = "削除",
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun RenameDialog(
    initialName: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var text by remember { mutableStateOf(initialName) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("ページ名を変更") },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                singleLine = true,
                label = { Text("名前") }
            )
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(text) },
                enabled = text.isNotBlank()
            ) {
                Text("保存")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("キャンセル")
            }
        }
    )
}
