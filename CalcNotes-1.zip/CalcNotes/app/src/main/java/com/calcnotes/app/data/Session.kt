package com.calcnotes.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 1つの「電卓ページ」を表す。ユーザーが名前を付けて複数作成・切り替えできる単位。
 */
@Entity(tableName = "sessions")
data class Session(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    // 一覧の並び替えに使う。値が小さいほど上に表示される
    val orderIndex: Long = System.currentTimeMillis()
)
