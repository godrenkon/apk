package com.calcnotes.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/**
 * 電卓のボタン配列。
 * 上段: 関数電卓ボタン(sin, cos, sqrtなど。折りたたみ可能)
 * 下段: 通常の四則演算ボタン
 */
@Composable
fun CalculatorKeypad(
    showScientific: Boolean,
    onToggleScientific: () -> Unit,
    onKeyPress: (String) -> Unit,
    onEquals: () -> Unit,
    onBackspace: () -> Unit,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(modifier = modifier.padding(8.dp)) {

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
        ) {
            TextButton(onClick = onToggleScientific) {
                Text(if (showScientific) "簡易電卓に切替" else "関数電卓に切替")
            }
        }

        if (showScientific) {
            val scientificKeys = listOf(
                "sin(", "cos(", "tan(", "sqrt(",
                "log(", "ln(", "(", ")",
                "^", "!", "pi", "e"
            )
            KeyGrid(keys = scientificKeys, columns = 4, onKeyPress = onKeyPress, isSecondary = true)
            Spacer(modifier = Modifier.height(4.dp))
        }

        val mainRows = listOf(
            listOf("C", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "⌫", "=")
        )

        mainRows.forEach { row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                row.forEach { key ->
                    CalcKeyButton(
                        label = key,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            when (key) {
                                "C" -> onClear()
                                "⌫" -> onBackspace()
                                "=" -> onEquals()
                                else -> onKeyPress(key)
                            }
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun KeyGrid(
    keys: List<String>,
    columns: Int,
    onKeyPress: (String) -> Unit,
    isSecondary: Boolean
) {
    keys.chunked(columns).forEach { rowKeys ->
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 3.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            rowKeys.forEach { key ->
                CalcKeyButton(
                    label = key,
                    modifier = Modifier.weight(1f),
                    isSecondary = isSecondary,
                    onClick = { onKeyPress(key) }
                )
            }
            // 列数が足りない最終行の余白埋め
            repeat(columns - rowKeys.size) {
                Spacer(modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
private fun CalcKeyButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    isSecondary: Boolean = false
) {
    val isOperator = label in listOf("÷", "×", "-", "+", "=")
    val colors = when {
        label == "=" -> ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.secondary,
            contentColor = MaterialTheme.colorScheme.onPrimary
        )
        label == "C" -> ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.error.copy(alpha = 0.15f),
            contentColor = MaterialTheme.colorScheme.error
        )
        isOperator -> ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
            contentColor = MaterialTheme.colorScheme.primary
        )
        isSecondary -> ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.8f)
        )
        else -> ButtonDefaults.buttonColors(
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = MaterialTheme.colorScheme.onSurface
        )
    }

    Button(
        onClick = onClick,
        modifier = modifier.height(if (isSecondary) 44.dp else 56.dp),
        colors = colors,
        contentPadding = PaddingValues(0.dp)
    ) {
        Text(
            text = label,
            fontWeight = if (label == "=") FontWeight.Bold else FontWeight.Medium
        )
    }
}
