package com.calcnotes.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface CalcNotesDao {

    // --- セッション(電卓ページ)関連 ---

    @Query("SELECT * FROM sessions ORDER BY orderIndex DESC")
    fun observeSessions(): Flow<List<Session>>

    @Insert
    suspend fun insertSession(session: Session): Long

    @Update
    suspend fun updateSession(session: Session)

    @Delete
    suspend fun deleteSession(session: Session)

    // --- 計算履歴関連 ---

    @Query("SELECT * FROM calculation_entries WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    fun observeEntries(sessionId: Long): Flow<List<CalculationEntry>>

    @Insert
    suspend fun insertEntry(entry: CalculationEntry): Long

    @Query("DELETE FROM calculation_entries WHERE sessionId = :sessionId")
    suspend fun clearEntries(sessionId: Long)

    @Query("DELETE FROM calculation_entries WHERE id = :entryId")
    suspend fun deleteEntry(entryId: Long)
}
