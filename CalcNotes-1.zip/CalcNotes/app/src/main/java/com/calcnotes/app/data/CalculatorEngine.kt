package com.calcnotes.app.data

import kotlin.math.*

/**
 * 数式の文字列を受け取って評価する電卓エンジン。
 *
 * 対応している記法:
 *  - 四則演算: + - × (または *) ÷ (または /)
 *  - 括弧: ( )
 *  - パーセント: 50% → 0.5 として計算(単独항のみ。 "100+10%" は "100 + 100*0.1" 的な直感的挙動)
 *  - 累乗: ^ (例: 2^10)
 *  - 階乗: ! (例: 5!)
 *  - 関数: sin, cos, tan, asin, acos, atan, sqrt, log(常用対数), ln(自然対数)
 *  - 定数: pi, e
 *
 * 実装は「再帰下降構文解析(recursive descent parser)」というシンプルな方式。
 * 優先順位: 括弧・関数 > 累乗・階乗 > 単項マイナス > 乗除 > 加減
 */
object CalculatorEngine {

    class CalculationError(message: String) : Exception(message)

    /**
     * 式を評価して結果の文字列を返す。失敗時は例外を投げる。
     */
    fun evaluate(rawExpression: String): String {
        val normalized = normalize(rawExpression)
        if (normalized.isBlank()) throw CalculationError("式が空です")

        val parser = Parser(normalized)
        val value = parser.parseExpression()
        parser.expectEnd()

        if (value.isNaN() || value.isInfinite()) {
            throw CalculationError("計算できません")
        }
        return formatResult(value)
    }

    /** 表示用記号を計算用記号に正規化する */
    private fun normalize(input: String): String {
        return input
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .replace(",", "")
            .replace(" ", "")
    }

    /** 結果を見やすい文字列に整形する(整数なら小数点を出さない、桁が多すぎる場合は丸める) */
    private fun formatResult(value: Double): String {
        val rounded = round(value * 1_000_000_000.0) / 1_000_000_000.0
        return if (rounded == floor(rounded) && abs(rounded) < 1e15) {
            rounded.toLong().toString()
        } else {
            rounded.toString().trimEnd('0').trimEnd('.')
        }
    }

    private class Parser(private val text: String) {
        private var pos = 0

        fun expectEnd() {
            if (pos != text.length) {
                throw CalculationError("式の形式が正しくありません")
            }
        }

        // 加減算(最も優先度が低い)
        fun parseExpression(): Double {
            var value = parseTerm()
            while (pos < text.length) {
                when (text[pos]) {
                    '+' -> { pos++; value += parseTerm() }
                    '-' -> { pos++; value -= parseTerm() }
                    else -> return value
                }
            }
            return value
        }

        // 乗除算
        private fun parseTerm(): Double {
            var value = parseUnary()
            while (pos < text.length) {
                when (text[pos]) {
                    '*' -> { pos++; value *= parseUnary() }
                    '/' -> {
                        pos++
                        val divisor = parseUnary()
                        if (divisor == 0.0) throw CalculationError("0で割ることはできません")
                        value /= divisor
                    }
                    else -> return value
                }
            }
            return value
        }

        // 単項マイナス・プラス
        private fun parseUnary(): Double {
            if (pos < text.length && text[pos] == '-') {
                pos++
                return -parseUnary()
            }
            if (pos < text.length && text[pos] == '+') {
                pos++
                return parseUnary()
            }
            return parsePower()
        }

        // 累乗(右結合: 2^3^2 = 2^(3^2))
        private fun parsePower(): Double {
            val base = parsePostfix()
            if (pos < text.length && text[pos] == '^') {
                pos++
                val exponent = parseUnary()
                return base.pow(exponent)
            }
            return base
        }

        // 階乗・パーセントなど後置演算子
        private fun parsePostfix(): Double {
            var value = parseAtom()
            while (pos < text.length) {
                when (text[pos]) {
                    '!' -> {
                        pos++
                        value = factorial(value)
                    }
                    '%' -> {
                        pos++
                        value /= 100.0
                    }
                    else -> return value
                }
            }
            return value
        }

        // 数値・括弧・関数・定数
        private fun parseAtom(): Double {
            if (pos >= text.length) throw CalculationError("式が不完全です")

            val c = text[pos]

            if (c == '(') {
                pos++
                val value = parseExpression()
                if (pos >= text.length || text[pos] != ')') {
                    throw CalculationError("括弧が閉じていません")
                }
                pos++
                return value
            }

            if (c.isDigit() || c == '.') {
                return parseNumber()
            }

            if (c.isLetter()) {
                return parseIdentifier()
            }

            throw CalculationError("不正な文字です: $c")
        }

        private fun parseNumber(): Double {
            val start = pos
            while (pos < text.length && (text[pos].isDigit() || text[pos] == '.')) {
                pos++
            }
            return text.substring(start, pos).toDoubleOrNull()
                ?: throw CalculationError("数値の形式が正しくありません")
        }

        private fun parseIdentifier(): Double {
            val start = pos
            while (pos < text.length && text[pos].isLetter()) {
                pos++
            }
            val name = text.substring(start, pos)

            // 定数
            when (name) {
                "pi" -> return PI
                "e" -> return E
            }

            // 関数呼び出しは "関数名(引数)" の形式を要求する
            if (pos >= text.length || text[pos] != '(') {
                throw CalculationError("未対応の関数・定数です: $name")
            }
            pos++
            val arg = parseExpression()
            if (pos >= text.length || text[pos] != ')') {
                throw CalculationError("括弧が閉じていません")
            }
            pos++

            return when (name) {
                "sin" -> sin(Math.toRadians(arg))
                "cos" -> cos(Math.toRadians(arg))
                "tan" -> tan(Math.toRadians(arg))
                "asin" -> Math.toDegrees(asin(arg))
                "acos" -> Math.toDegrees(acos(arg))
                "atan" -> Math.toDegrees(atan(arg))
                "sqrt" -> {
                    if (arg < 0) throw CalculationError("負の数の平方根は計算できません")
                    sqrt(arg)
                }
                "log" -> log10(arg)
                "ln" -> ln(arg)
                "abs" -> abs(arg)
                else -> throw CalculationError("未対応の関数です: $name")
            }
        }

        private fun factorial(value: Double): Double {
            if (value < 0 || value != floor(value)) {
                throw CalculationError("階乗は0以上の整数のみ計算できます")
            }
            if (value > 170) throw CalculationError("値が大きすぎます")
            var result = 1.0
            var n = value.toInt()
            while (n > 1) {
                result *= n
                n--
            }
            return result
        }
    }
}
