package com.calcnotes.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [Session::class, CalculationEntry::class],
    version = 1,
    exportSchema = false
)
abstract class CalcNotesDatabase : RoomDatabase() {

    abstract fun dao(): CalcNotesDao

    companion object {
        @Volatile
        private var INSTANCE: CalcNotesDatabase? = null

        fun getInstance(context: Context): CalcNotesDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    CalcNotesDatabase::class.java,
                    "calcnotes.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
