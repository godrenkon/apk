package com.calcnotes.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.calcnotes.app.data.CalculationEntry

/**
 * 1回分の計算を「式(左寄せ・控えめ)」→「答え(右寄せ・強調)」の
 * 2つの吹き出しで表示する。チャットのやり取りのような見た目にする。
 *
 * 長押しで削除できるようにonLongPressを用意。
 */
@Composable
fun CalculationBubble(
    entry: CalculationEntry,
    onLongPress: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .fillMaxWidth()
            .combinedClickable(onClick = {}, onLongClick = onLongPress)
            .padding(vertical = 6.dp)
    ) {
        // 式(問い): 左寄せ、控えめな色
        Box(
            modifier = Modifier
                .align(Alignment.Start)
                .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 16.dp, bottomStart = 16.dp, bottomEnd = 16.dp))
                .background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Text(
                text = entry.expression,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // 答え: 右寄せ、強調
        Box(
            modifier = Modifier
                .align(Alignment.End)
                .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 4.dp, bottomStart = 16.dp, bottomEnd = 16.dp))
                .background(MaterialTheme.colorScheme.primary)
                .padding(horizontal = 14.dp, vertical = 8.dp)
        ) {
            Text(
                text = "= ${entry.result}",
                style = MaterialTheme.typography.bodyLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimary
            )
        }
    }
}
