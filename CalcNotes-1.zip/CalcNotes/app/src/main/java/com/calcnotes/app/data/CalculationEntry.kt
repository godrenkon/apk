package com.calcnotes.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * 電卓ページ内の1回分の計算(吹き出し1組: 式 → 答え)。
 * sessionIdが削除されたセッションを指す場合は連動して削除される(CASCADE)。
 */
@Entity(
    tableName = "calculation_entries",
    foreignKeys = [
        ForeignKey(
            entity = Session::class,
            parentColumns = ["id"],
            childColumns = ["sessionId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("sessionId")]
)
data class CalculationEntry(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sessionId: Long,
    val expression: String,
    val result: String,
    val timestamp: Long = System.currentTimeMillis()
)
