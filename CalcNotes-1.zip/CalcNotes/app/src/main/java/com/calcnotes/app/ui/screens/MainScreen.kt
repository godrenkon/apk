package com.calcnotes.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.calcnotes.app.data.CalcNotesViewModel
import com.calcnotes.app.ui.components.CalculationBubble
import com.calcnotes.app.ui.components.CalculatorKeypad
import com.calcnotes.app.ui.components.SessionSidebar
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: CalcNotesViewModel = viewModel()) {
    val sessions by viewModel.sessions.collectAsState()
    val currentSessionId by viewModel.currentSessionId.collectAsState()
    val entries by viewModel.currentEntries.collectAsState()
    val errorMessage by viewModel.errorMessage.collectAsState()

    var expression by remember { mutableStateOf("") }
    var showScientific by remember { mutableStateOf(false) }

    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()

    val currentSession = sessions.firstOrNull { it.id == currentSessionId }

    // 新しい計算が追加されたら一番下(最新)にスクロールする
    LaunchedEffect(entries.size) {
        if (entries.isNotEmpty()) {
            listState.animateScrollToItem(entries.size - 1)
        }
    }

    // エラーはスナックバーで一時的に表示する
    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(errorMessage) {
        errorMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearError()
        }
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet {
                SessionSidebar(
                    sessions = sessions,
                    currentSessionId = currentSessionId,
                    onSelect = { session ->
                        viewModel.selectSession(session.id)
                        expression = ""
                        scope.launch { drawerState.close() }
                    },
                    onCreate = {
                        val nextIndex = sessions.size + 1
                        viewModel.createSession("電卓 $nextIndex")
                        expression = ""
                    },
                    onRename = { session, newName -> viewModel.renameSession(session, newName) },
                    onDelete = { session -> viewModel.deleteSession(session) },
                    modifier = Modifier
                        .fillMaxHeight()
                        .widthIn(max = 300.dp)
                )
            }
        }
    ) {
        Scaffold(
            snackbarHost = { SnackbarHost(snackbarHostState) },
            topBar = {
                TopAppBar(
                    title = { Text(currentSession?.name ?: "CalcNotes") },
                    navigationIcon = {
                        IconButton(onClick = { scope.launch { drawerState.open() } }) {
                            Icon(Icons.Filled.Menu, contentDescription = "電卓ページ一覧")
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.clearCurrentSessionHistory() }) {
                            Icon(Icons.Filled.DeleteSweep, contentDescription = "この履歴を全消去")
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
            ) {
                // 計算履歴(チャット風吹き出し)
                if (entries.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "計算するとここに履歴が残ります",
                            style = MaterialTheme.typography.bodyMedium
                        )
                    }
                } else {
                    LazyColumn(
                        state = listState,
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        items(entries, key = { it.id }) { entry ->
                            CalculationBubble(
                                entry = entry,
                                onLongPress = { viewModel.deleteEntry(entry.id) }
                            )
                        }
                    }
                }

                // 現在入力中の式のプレビュー欄
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    tonalElevation = 1.dp
                ) {
                    Text(
                        text = expression.ifEmpty { "0" },
                        style = MaterialTheme.typography.headlineMedium,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.End
                    )
                }

                CalculatorKeypad(
                    showScientific = showScientific,
                    onToggleScientific = { showScientific = !showScientific },
                    onKeyPress = { key -> expression += key },
                    onEquals = {
                        if (expression.isNotBlank()) {
                            viewModel.calculate(expression)
                            expression = ""
                        }
                    },
                    onBackspace = {
                        if (expression.isNotEmpty()) {
                            expression = expression.dropLast(1)
                        }
                    },
                    onClear = { expression = "" }
                )
            }
        }
    }
}
