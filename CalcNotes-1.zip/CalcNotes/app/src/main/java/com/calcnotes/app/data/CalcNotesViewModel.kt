package com.calcnotes.app.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class CalcNotesViewModel(application: Application) : AndroidViewModel(application) {

    private val dao = CalcNotesDatabase.getInstance(application).dao()

    // 全セッション(電卓ページ)の一覧。新しい順に並ぶ
    val sessions: StateFlow<List<Session>> = dao.observeSessions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // 現在選択中のセッションID。未選択ならnull
    private val _currentSessionId = MutableStateFlow<Long?>(null)
    val currentSessionId: StateFlow<Long?> = _currentSessionId

    // 選択中セッションの計算履歴
    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val currentEntries: StateFlow<List<CalculationEntry>> = _currentSessionId
        .flatMapLatest { id ->
            if (id == null) flowOf(emptyList())
            else dao.observeEntries(id)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // 直近の計算エラーメッセージ(nullなら表示なし)
    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage

    init {
        // 起動時に一度だけ、DBの現在の状態を見て初期選択を行う。
        // セッションが1つもなければ最初のページを自動作成し、あれば先頭を選択する。
        viewModelScope.launch {
            val loaded = dao.observeSessions().first()
            if (loaded.isEmpty()) {
                createSession("電卓 1")
            } else {
                _currentSessionId.value = loaded.first().id
            }
        }
    }

    fun selectSession(sessionId: Long) {
        _currentSessionId.value = sessionId
    }

    fun createSession(name: String) {
        viewModelScope.launch {
            val newId = dao.insertSession(Session(name = name))
            _currentSessionId.value = newId
        }
    }

    fun renameSession(session: Session, newName: String) {
        if (newName.isBlank()) return
        viewModelScope.launch {
            dao.updateSession(session.copy(name = newName))
        }
    }

    fun deleteSession(session: Session) {
        viewModelScope.launch {
            dao.deleteSession(session)
            if (_currentSessionId.value == session.id) {
                _currentSessionId.value = sessions.value.firstOrNull { it.id != session.id }?.id
            }
        }
    }

    /** 式を評価して結果を履歴に保存する。失敗時はerrorMessageにセットする */
    fun calculate(expression: String) {
        val sessionId = _currentSessionId.value ?: return
        if (expression.isBlank()) return

        viewModelScope.launch {
            try {
                val result = CalculatorEngine.evaluate(expression)
                dao.insertEntry(
                    CalculationEntry(
                        sessionId = sessionId,
                        expression = expression,
                        result = result
                    )
                )
                _errorMessage.value = null
            } catch (e: CalculatorEngine.CalculationError) {
                _errorMessage.value = e.message
            } catch (e: Exception) {
                _errorMessage.value = "計算できませんでした"
            }
        }
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun clearCurrentSessionHistory() {
        val sessionId = _currentSessionId.value ?: return
        viewModelScope.launch {
            dao.clearEntries(sessionId)
        }
    }

    fun deleteEntry(entryId: Long) {
        viewModelScope.launch {
            dao.deleteEntry(entryId)
        }
    }
}
