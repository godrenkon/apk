# CalcNotes

計算結果がずっと保存される電卓アプリ。Gemini/Claudeのチャットのように、
「電卓ページ」を複数作って名前を付け、使い分けられます。

## 主な機能

- **チャット風の計算履歴**: 式(左側の吹き出し)→ 答え(右側の吹き出し)の形で
  計算の流れが積み重なって残ります。
- **複数の電卓ページ**: 左のサイドバーからページを新規作成・名前変更・削除・切り替え。
  ページごとに履歴が独立して保存されます。
- **永続化**: Room(SQLite)を使ってローカルに保存。アプリを閉じても消えません。
- **関数電卓モード**: 四則演算・括弧・%に加えて、sin/cos/tan・sqrt・log・ln・
  累乗(^)・階乗(!)・piやeの定数にも対応。
- **履歴の削除**: 吹き出しを長押しで1件削除、右上のアイコンでページ全消去。

## セットアップ手順(Android Studio)

1. Android Studio(最新の Iguana 以降推奨)をインストール
2. `File > Open` でこの `CalcNotes` フォルダを開く
3. Gradle Syncが自動で走るのを待つ(初回はライブラリのダウンロードで数分かかることがあります)
4. 実機またはエミュレータ(API 26以上)を選んで ▶ Run

## GitHub ActionsでAPKを自動ビルドする(PC不要)

Android Studioがなくても、GitHubにアップロードするだけでクラウド上でAPKが作れます。

1. GitHubで新しいリポジトリを作成(例: `CalcNotes`)
2. このフォルダの中身(`.github`フォルダも含めて)をすべてそのリポジトリにアップロード
   - スマホのGitHubアプリやブラウザ版から、ファイルをドラッグ&ドロップでアップロード可能
   - または `git push` でPCから送ってもOK
3. アップロード([Push])すると自動的にビルドが始まる(`.github/workflows/build-apk.yml`が実行される)
4. リポジトリ上部の **「Actions」タブ** を開く
5. 実行中/完了したワークフロー(「Build APK」)をタップ
6. 一番下の **「Artifacts」** 欄に `CalcNotes-debug-apk` が表示されるのでタップしてダウンロード
7. ダウンロードされるのはzipファイルなので、解凍すると中に `app-debug.apk` が入っている
8. そのAPKをスマホに転送してインストール(「提供元不明のアプリ」の許可が必要な場合あり)

※ これは署名なしのデバッグ用APKです。自分のスマホで使う分には問題ありませんが、
Google Playへの公開には別途「署名付きリリースビルド」の設定が必要です。

## プロジェクト構成

```
app/src/main/java/com/calcnotes/app/
├── MainActivity.kt              # エントリーポイント
├── data/
│   ├── Session.kt                # 電卓ページのデータモデル
│   ├── CalculationEntry.kt       # 1回分の計算(式と答え)のデータモデル
│   ├── CalcNotesDao.kt           # DB操作(Room DAO)
│   ├── CalcNotesDatabase.kt      # Roomデータベース定義
│   ├── CalculatorEngine.kt       # 数式を解釈・計算するエンジン
│   └── CalcNotesViewModel.kt     # 画面とDBをつなぐロジック
└── ui/
    ├── theme/                    # 配色・フォント
    ├── components/
    │   ├── SessionSidebar.kt     # ページ一覧サイドバー
    │   ├── CalculationBubble.kt  # チャット風の吹き出し
    │   └── CalculatorKeypad.kt   # 電卓ボタン
    └── screens/
        └── MainScreen.kt         # 全体を組み合わせたメイン画面
```

## 今後拡張しやすい部分

- ページの並び替え(ドラッグ&ドロップ)
- 計算履歴のエクスポート(テキスト・CSV)
- ダークモードの手動切り替え
- 電卓ページごとのアイコン・色分け
